from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from typing import Any
import os

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

try:
    from panchang import panchang, calendar as panchang_calendar, Location
except ImportError as exc:
    raise RuntimeError(
        "Install dependencies first: pip install -r requirements.txt"
    ) from exc

app = FastAPI(title="Real-Time Hindu Panchang API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# South-Indian/Telugu-facing traditional names.
TITHI_NAMES = {
    1:"Pratipada",2:"Dvitiya",3:"Tritiya",4:"Chaturthi",5:"Panchami",
    6:"Shashthi",7:"Saptami",8:"Ashtami",9:"Navami",10:"Dashami",
    11:"Ekadashi",12:"Dwadashi",13:"Trayodashi",14:"Chaturdashi",
    15:"Purnima",16:"Pratipada",17:"Dvitiya",18:"Tritiya",19:"Chaturthi",
    20:"Panchami",21:"Shashthi",22:"Saptami",23:"Ashtami",24:"Navami",
    25:"Dashami",26:"Ekadashi",27:"Dwadashi",28:"Trayodashi",
    29:"Chaturdashi",30:"Amavasya"
}

NAKSHATRAS = [
    "Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra",
    "Punarvasu","Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni",
    "Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha","Mula",
    "Purva Ashadha","Uttara Ashadha","Shravana","Dhanishtha","Shatabhisha",
    "Purva Bhadrapada","Uttara Bhadrapada","Revati"
]

# Drik Panchang's published Nakshatra Thyajyam table:
# start position expressed as ghatis out of the 60-ghati nakshatra span.
# Values are 51..54, 25..28, etc.; the first number is the start.
VARJYA_GHATIS = {
    "Ashwini":51, "Bharani":25, "Krittika":31, "Rohini":41,
    "Mrigashira":15, "Ardra":22, "Punarvasu":31, "Pushya":21,
    "Ashlesha":33, "Magha":31, "Purva Phalguni":21, "Uttara Phalguni":19,
    "Hasta":22, "Chitra":21, "Swati":15, "Vishakha":15,
    "Anuradha":11, "Jyeshtha":15, "Mula":57, "Purva Ashadha":25,
    "Uttara Ashadha":21, "Shravana":11, "Dhanishtha":11, "Shatabhisha":19,
    "Purva Bhadrapada":17, "Uttara Bhadrapada":25, "Revati":31,
}

# A common South-Indian/Telugu convention for Amrita Kalam:
# use the same 4/60 window 24 ghatis after Varjyam.
# Keep this configurable because calendars differ on detailed conventions.
AMRITA_OFFSET_GHATIS = 24.0

RAHU_INDEX = {6: 7, 0: 1, 1: 6, 2: 4, 3: 5, 4: 3, 5: 2}
# Python weekday: Mon=0 ... Sun=6. Values are 1-based daylight eighths.
YAMA_INDEX = {6: 4, 0: 2, 1: 3, 2: 4, 3: 5, 4: 6, 5: 7}
GULIKA_INDEX = {6: 7, 0: 6, 1: 5, 2: 4, 3: 3, 4: 2, 5: 1}

# Widely used South-Indian Durmuhurtham positions in the 15 daytime divisions.
# The Tuesday second interval is a night division.
DUR_DAY = {
    6: [8],        # Sunday
    0: [5],        # Monday
    1: [3],        # Tuesday
    2: [4],        # Wednesday
    3: [3, 8],     # Thursday
    4: [3],        # Friday
    5: [2],        # Saturday
}
DUR_NIGHT_TUESDAY = 7

CITY_COORDS = {
    "bengaluru": (12.9716,77.5946,"Asia/Kolkata"),
    "bangalore": (12.9716,77.5946,"Asia/Kolkata"),
    "hyderabad": (17.3850,78.4867,"Asia/Kolkata"),
    "srisailam": (16.0720,78.8680,"Asia/Kolkata"),
    "chennai": (13.0827,80.2707,"Asia/Kolkata"),
    "mumbai": (19.0760,72.8777,"Asia/Kolkata"),
    "delhi": (28.6139,77.2090,"Asia/Kolkata"),
    "new delhi": (28.6139,77.2090,"Asia/Kolkata"),
    "tirupati": (13.6288,79.4192,"Asia/Kolkata"),
    "vijayawada": (16.5062,80.6480,"Asia/Kolkata"),
    "varanasi": (25.3176,82.9739,"Asia/Kolkata"),
    "pune": (18.5204,73.8567,"Asia/Kolkata"),
    "kolkata": (22.5726,88.3639,"Asia/Kolkata"),
    "jaipur": (26.9124,75.7873,"Asia/Kolkata"),
}

def obj_get(obj: Any, *names: str, default=None):
    for name in names:
        if isinstance(obj, dict) and name in obj:
            return obj[name]
        if hasattr(obj, name):
            return getattr(obj, name)
    return default

def as_dt(v: Any, tz: ZoneInfo | None = None):
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.astimezone(tz) if tz and v.tzinfo else v.replace(tzinfo=tz) if tz else v
    if isinstance(v, str):
        try:
            d = datetime.fromisoformat(v.replace("Z","+00:00"))
            return d.astimezone(tz) if tz and d.tzinfo else d.replace(tzinfo=tz) if tz else d
        except ValueError:
            return None
    return None

def iso(v: Any, tz: ZoneInfo):
    d = as_dt(v, tz)
    return d.isoformat() if d else None

def display_tithi(t: Any):
    name = obj_get(t, "name", default=None)
    paksha = obj_get(t, "paksha", default=None)
    if name and paksha and str(paksha).lower() not in str(name).lower():
        return f"{paksha} {name}"
    return name or "—"

def resolve_place(place: str, lat: float | None, lng: float | None, tz: str | None):
    if lat is not None and lng is not None:
        zone = tz or "UTC"
        return place or "Selected location", float(lat), float(lng), zone

    key = place.strip().lower()
    for name, values in CITY_COORDS.items():
        if key == name or key.startswith(name + ",") or name in key:
            return place, values[0], values[1], tz or values[2]

    raise HTTPException(
        status_code=400,
        detail="Unknown place. Use a supported city name or send lat/lng/tz from browser geolocation."
    )

def daylight_window(sunrise: datetime, sunset: datetime, index: int, units: int = 8):
    duration = (sunset - sunrise) / units
    start = sunrise + duration * (index - 1)
    return {"start": start, "end": start + duration}

def daytime_muhurta(sunrise: datetime, sunset: datetime, position: int):
    duration = (sunset - sunrise) / 15
    start = sunrise + duration * (position - 1)
    return {"start": start, "end": start + duration}

def night_muhurta(sunset: datetime, next_sunrise: datetime, position: int):
    duration = (next_sunrise - sunset) / 15
    start = sunset + duration * (position - 1)
    return {"start": start, "end": start + duration}

def candidate_to_window(v, tz):
    return {"start": iso(v["start"],tz), "end": iso(v["end"],tz)}

def build_varjyam(nak_name: str, nak_start: datetime | None, nak_end: datetime | None, sunrise: datetime, next_sunrise: datetime):
    if not nak_start or not nak_end or nak_end <= nak_start:
        return []
    frac = VARJYA_GHATIS.get(nak_name)
    if frac is None:
        return []
    span = nak_end - nak_start
    start = nak_start + span * (frac / 60.0)
    length = span * (4.0 / 60.0)
    end = start + length
    # Return any portion whose start is inside this Panchang day.
    if sunrise <= start < next_sunrise:
        return [{"start": start, "end": end}]
    return []

def build_amrita(nak_name: str, nak_start: datetime | None, nak_end: datetime | None, sunrise: datetime, next_sunrise: datetime):
    if not nak_start or not nak_end or nak_end <= nak_start:
        return []
    frac = VARJYA_GHATIS.get(nak_name)
    if frac is None:
        return []
    span = nak_end - nak_start
    start = nak_start + span * ((frac + AMRITA_OFFSET_GHATIS) / 60.0)
    end = start + span * (4.0 / 60.0)
    if sunrise <= start < next_sunrise:
        return [{"start": start, "end": end}]
    return []

def get_transition_start(compute_fn, target_end: datetime, approx_hours: int = 30):
    # The Panchang package gives boundary/end times. We can get the preceding
    # boundary by computing the same date at the previous civil day and using
    # the returned boundary where appropriate. This is a conservative fallback.
    try:
        previous = compute_fn(target_end.date() - timedelta(days=1))
        val = obj_get(previous, "nakshatra_ends_at", "nakshatra_end", default=None)
        d = as_dt(val, target_end.tzinfo)
        if d and d < target_end:
            return d
    except Exception:
        pass
    return target_end - timedelta(hours=24)

def sankalpam(data, tradition: str):
    cal = data["calendar"]
    p = data["locationPhrase"]
    common = (
        "śrīmad-bhagavato mahāpuruṣasya viṣṇorājñayā pravartamānasya\n"
        "adya brahmaṇaḥ dvitīye parārdhe śrī-śvetavarāha-kalpe\n"
        "vaivasvata-manvantare kaliyuge prathame pāde\n"
        f"{cal['samvatsara']} nāma saṃvatsare\n"
        f"{cal['ayana']} ayane {cal['ritu']} ṛtau\n"
        f"{cal['masa']} māse {cal['paksha']} pakṣe\n"
        f"{data['tithi']['display']} tithau\n"
        f"{data['vara']['name']} vāsare\n"
        f"{data['nakshatra']['display']} nakṣatre\n"
        f"{p}\n"
    )
    tail = (
        "mama upātta-samasta-durita-kṣaya-dvāra "
        "śrī-parameśvara-prītyarthaṃ "
    )
    if tradition == "telugu":
        tail += "śrī-parameśvara-pūjāṃ kariṣye."
    else:
        tail += "yathāśakti dhyāna-japa-pūjādi-karma kariṣye."
    return common + "\n" + tail

def location_phrase(place: str):
    p = place.lower()
    if "srisailam" in p:
        return "śrīśailasya āgneya-pradeśe, bhārata-deśe"
    if "bengaluru" in p or "bangalore" in p:
        return "Bengalūru-nagare, Karnāṭaka-rājye, Bhārata-deśe"
    if "hyderabad" in p:
        return "Bhāgya-nagare, Telangāṇa-rājye, Bhārata-deśe"
    if "chennai" in p:
        return "Chennai-nagare, Tamilnāḍu-rājye, Bhārata-deśe"
    if "mumbai" in p:
        return "Mumbaī-nagare, Mahārāṣṭra-rājye, Bhārata-deśe"
    return f"{place}, Bhārata-deśe"

def extract_calendar(pc: Any, target_date: date):
    # The exact attribute names are intentionally probed to support minor package
    # API changes without changing this application's API.
    sam = obj_get(pc, "samvatsara", "samvatsara_name", default="—")
    ayana = obj_get(pc, "ayana", "ayana_name", default="—")
    ritu = obj_get(pc, "ritu", "ritu_name", default="—")
    masa = obj_get(pc, "masa", "lunar_month", "month", default="—")
    paksha = obj_get(pc, "paksha", default=None)
    t = obj_get(pc, "tithi", default=None)
    if paksha is None and t is not None:
        paksha = obj_get(t, "paksha", default="—")
    return {
        "samvatsara": str(sam),
        "ayana": str(ayana),
        "ritu": str(ritu),
        "masa": str(masa),
        "paksha": str(paksha or "—"),
    }

@app.get("/api/health")
def health():
    return {"ok": True, "engine": "panchang 0.2.x + astronomical backend"}

@app.get("/api/panchang")
def daily_panchang(
    date_: str = Query(..., alias="date"),
    place: str = "Bengaluru, Karnataka, India",
    tradition: str = "telugu",
    lat: float | None = None,
    lng: float | None = None,
    tz: str | None = None,
):
    try:
        target = date.fromisoformat(date_)
    except ValueError:
        raise HTTPException(400, "date must be YYYY-MM-DD")

    place_name, latitude, longitude, tz_name = resolve_place(place, lat, lng, tz)

    try:
        zone = ZoneInfo(tz_name)
    except Exception:
        raise HTTPException(400, f"Invalid IANA timezone: {tz_name}")

    loc = Location(lat=latitude, lng=longitude, tz=tz_name)
    pc = panchang.compute(target, loc)

    sunrise = as_dt(obj_get(obj_get(pc, "sun", default=pc), "sunrise", default=None), zone)
    sunset = as_dt(obj_get(obj_get(pc, "sun", default=pc), "sunset", default=None), zone)
    if not sunrise or not sunset:
        raise HTTPException(500, "Panchang engine did not return sunrise/sunset")

    next_pc = panchang.compute(target + timedelta(days=1), loc)
    next_sunrise = as_dt(obj_get(obj_get(next_pc, "sun", default=next_pc), "sunrise", default=None), zone)
    if not next_sunrise:
        next_sunrise = sunrise + timedelta(days=1)

    t = obj_get(pc, "tithi", default=None)
    n = obj_get(pc, "nakshatra", default=None)
    y = obj_get(pc, "yoga", default=None)
    k = obj_get(pc, "karana", default=None)

    t_end = as_dt(obj_get(t, "ends_at", "end", "tithi_ends_at", default=None), zone)
    n_end = as_dt(obj_get(n, "ends_at", "end", "nakshatra_ends_at", default=None), zone)
    y_end = as_dt(obj_get(y, "ends_at", "end", "yoga_ends_at", default=None), zone)
    k_end = as_dt(obj_get(k, "ends_at", "end", "karana_ends_at", default=None), zone)

    # Obtain previous nakshatra boundary for Varjyam/Amrita.
    def compute_for(d):
        return panchang.compute(d, loc)

    n_start = get_transition_start(compute_for, n_end) if n_end else None
    n_name = obj_get(n, "name", default="—")

    weekday = target.weekday()
    rahu = [daylight_window(sunrise, sunset, RAHU_INDEX[weekday])]
    yama = [daylight_window(sunrise, sunset, YAMA_INDEX[weekday])]
    gulika = [daylight_window(sunrise, sunset, GULIKA_INDEX[weekday])]

    dur = [daytime_muhurta(sunrise, sunset, i) for i in DUR_DAY[weekday]]
    if weekday == 1:
        dur.append(night_muhurta(sunset, next_sunrise, DUR_NIGHT_TUESDAY))

    midday = sunrise + (sunset - sunrise) / 2
    abhijit_len = (sunset - sunrise) / 30
    abhijit = [] if weekday == 2 else [{"start": midday - abhijit_len, "end": midday + abhijit_len}]

    brahma = [{"start": sunrise - timedelta(minutes=96), "end": sunrise - timedelta(minutes=48)}]
    varjyam = build_varjyam(n_name, n_start, n_end, sunrise, next_sunrise)
    amrita = build_amrita(n_name, n_start, n_end, sunrise, next_sunrise)

    vara_name = target.strftime("%A")

    data = {
        "date": target.isoformat(),
        "place": place_name,
        "latitude": latitude,
        "longitude": longitude,
        "timezone": tz_name,
        "sunrise": sunrise.isoformat(),
        "sunset": sunset.isoformat(),
        "vara": {"name": vara_name, "end": next_sunrise.isoformat()},
        "tithi": {
            "display": display_tithi(t),
            "end": t_end.isoformat() if t_end else None,
        },
        "nakshatra": {
            "display": n_name,
            "end": n_end.isoformat() if n_end else None,
        },
        "yoga": {
            "display": obj_get(y, "name", default="—"),
            "end": y_end.isoformat() if y_end else None,
        },
        "karana": {
            "display": obj_get(k, "name", default="—"),
            "end": k_end.isoformat() if k_end else None,
        },
        "calendar": extract_calendar(pc, target),
        "timings": {
            "rahu": [candidate_to_window(x, zone) for x in rahu],
            "yamaganda": [candidate_to_window(x, zone) for x in yama],
            "gulika": [candidate_to_window(x, zone) for x in gulika],
            "durmuhurtham": [candidate_to_window(x, zone) for x in dur],
            "abhijit": [candidate_to_window(x, zone) for x in abhijit],
            "brahma": [candidate_to_window(x, zone) for x in brahma],
            "varjyam": [candidate_to_window(x, zone) for x in varjyam],
            "amrita": [candidate_to_window(x, zone) for x in amrita],
        },
        "festivals": [],
        "locationPhrase": location_phrase(place_name),
    }

    # Festival engine is part of the MIT panchang package. We filter to the
    # requested date and expose its names without scraping external websites.
    try:
        festivals = panchang_calendar.compute_festivals(target.year, loc)
        for f in festivals:
            fdate = obj_get(f, "date", default=None)
            if str(fdate)[:10] == target.isoformat():
                data["festivals"].append({
                    "name": str(obj_get(f, "name", default="Festival")),
                    "type": str(obj_get(f, "type", default="Festival")),
                })
    except Exception:
        # Calendar engine can evolve independently from daily computation.
        pass

    data["sankalpam"] = sankalpam(data, tradition)
    return data
