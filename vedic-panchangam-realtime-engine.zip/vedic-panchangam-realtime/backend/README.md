# Real-Time Panchangam API

This backend computes Panchangam on request rather than using hard-coded daily values.

## Engine

The project uses the `panchang` Python package (0.2.15), which publishes a MIT-licensed API backed by a Rust computation core and Swiss Ephemeris. It exposes Tithi, Nakshatra, Yoga, Karana, Vara, sunrise/sunset, Rahu Kalam, Yamaganda, Gulika, Abhijit, festivals and regional calendar systems.

This application adds:
- location-aware API
- traditional location phrases for Sankalpam
- Varjyam calculation using the published Nakshatra Thyajyam table
- Amrita Kalam as a configurable related window
- Durmuhurtham windows
- Sankalpam generation

## Install

Python 3.11+ is recommended.

```bash
cd backend
python -m venv .venv

# macOS/Linux
source .venv/bin/activate

# Windows
# .venv\Scripts\activate

pip install -r requirements.txt
```

## Run

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Health check:

```text
http://localhost:8000/api/health
```

Example:

```text
http://localhost:8000/api/panchang?date=2026-09-06&place=Bengaluru,%20Karnataka,%20India
```

## Frontend

Open `frontend/index.html` through a local static server rather than `file://`:

```bash
cd frontend
python -m http.server 5500
```

Then open:

```text
http://localhost:5500
```

The frontend calls `http://localhost:8000`.

## Location

For production, browser geolocation is preferred:

```text
lat + lng + IANA timezone
```

The API also contains a small city-coordinate table for common Indian cities. Unknown city names should be resolved by your production geocoder and then sent as coordinates.

## Panchang tradition

The default astronomical basis is Lahiri/Chitrapaksha through the underlying Panchang engine. Regional festival and month rules can differ. The UI currently offers Telugu/South Indian and Smarta/general Sankalpam wording.

## Important religious-calculation note

Panchangam is tradition-dependent. Varjyam and Durmuhurtham also have regional conventions. This project deliberately keeps those rules visible and configurable instead of pretending there is one universal convention.

For important ceremonies, validate against the family/temple Panchangam or priest.

## Production hardening

Before public deployment:
1. Pin dependency hashes.
2. Replace `allow_origins=["*"]` with your website domain.
3. Add response caching by date + lat + lng + timezone + tradition.
4. Add a production geocoder with caching/rate-limit handling.
5. Add automated comparison tests against your chosen reference Panchang.
6. Keep festival rules and Sankalpam location phrases in versioned data.
7. Add HTTPS and rate limiting.
