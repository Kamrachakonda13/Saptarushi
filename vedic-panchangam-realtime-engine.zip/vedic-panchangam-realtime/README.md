# Real-Time Vedic Panchangam Website Module

A copy-and-run frontend + FastAPI backend for a location-aware Hindu Panchangam.

## What is real-time here?

The site does NOT store today's Tithi/Nakshatra as fixed JavaScript values.

Each request is calculated for:
- selected date
- latitude
- longitude
- timezone

The astronomical engine supplies the Panchanga values and sunrise/sunset. The application derives additional location-dependent windows and generates the Sankalpam.

## Included

- Tithi
- Vara
- Nakshatra
- Yoga
- Karana
- Sunrise
- Sunset
- Rahu Kalam
- Yamaganda
- Gulika
- Abhijit Muhurta
- Brahma Muhurta
- Durmuhurtham
- Varjyam
- Amrita Kalam
- Festival/Vratam output
- Telugu/South Indian Sankalpam
- Smarta/general Sankalpam
- Location phrase such as:
  `śrīśailasya āgneya-pradeśe, bhārata-deśe`
- Browser geolocation
- API endpoint suitable for your temple website

## Run

Terminal 1:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Terminal 2:

```bash
cd frontend
python -m http.server 5500
```

Open:

http://localhost:5500

## Architecture

Browser -> FastAPI -> Panchang astronomical engine -> JSON -> Browser

## Accuracy policy

Do not compare two Panchangams without first fixing:
- ayanamsa
- sunrise model
- lunar month convention
- regional festival convention
- Durmuhurtham/Varjyam convention

The project is designed so these choices can be made explicit rather than hidden.

## License

Your application code in this project is provided as an example by OpenAI. The `panchang` dependency is separately licensed by its authors under MIT; review its current license and dependencies before commercial deployment.
