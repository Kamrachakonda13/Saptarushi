#!/usr/bin/env bash
set -e
cd frontend
python3 -m http.server 5500
