const $ = id => document.getElementById(id);
const API = window.PANCHANG_API_BASE || "http://localhost:8000";

function isoToday(){
  const d=new Date(), m=String(d.getMonth()+1).padStart(2,"0"), day=String(d.getDate()).padStart(2,"0");
  return `${d.getFullYear()}-${m}-${day}`;
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function set(id,v){$(id).textContent=v??"—";}
function fmtDate(s){return new Date(`${s}T12:00:00`).toLocaleDateString(undefined,{weekday:"long",year:"numeric",month:"long",day:"numeric"});}
function fmtTime(v){if(!v)return "—"; return new Date(v).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});}
function rangeList(xs){if(!xs||!xs.length)return "—";return xs.map(x=>`${fmtTime(x.start)} – ${fmtTime(x.end)}`).join(" · ");}

function render(d){
  $("headerDate").textContent=fmtDate(d.date);
  set("outPlace",d.place); set("sunrise",fmtTime(d.sunrise)); set("sunset",fmtTime(d.sunset)); set("timezone",d.timezone);
  set("vara",d.vara.name); set("varaEnd",d.vara.end ? `Until ${fmtTime(d.vara.end)}` : "Sunrise day");
  set("tithi",d.tithi.display); set("tithiEnd",d.tithi.end ? `Until ${fmtTime(d.tithi.end)}`:"");
  set("nakshatra",d.nakshatra.display); set("nakEnd",d.nakshatra.end ? `Until ${fmtTime(d.nakshatra.end)}`:"");
  set("yoga",d.yoga.display); set("yogaEnd",d.yoga.end ? `Until ${fmtTime(d.yoga.end)}`:"");
  set("karana",d.karana.display); set("karanaEnd",d.karana.end ? `Until ${fmtTime(d.karana.end)}`:"");
  set("samvatsara",d.calendar.samvatsara);set("ayana",d.calendar.ayana);set("ritu",d.calendar.ritu);set("masa",d.calendar.masa);set("paksha",d.calendar.paksha);
  set("abhijit",rangeList(d.timings.abhijit));set("amrita",rangeList(d.timings.amrita));set("rahu",rangeList(d.timings.rahu));set("yama",rangeList(d.timings.yamaganda));set("gulika",rangeList(d.timings.gulika));set("dur",rangeList(d.timings.durmuhurtham));set("varjyam",rangeList(d.timings.varjyam));set("brahma",rangeList(d.timings.brahma));
  $("locationPhrase").textContent=d.locationPhrase;
  $("sankalpam").textContent=d.sankalpam;
  $("festivalList").innerHTML=d.festivals.length ? d.festivals.map(f=>`<div class="festivalItem"><b>${esc(f.name)}</b><span class="tag">${esc(f.type||"Festival")}</span></div>`).join("") : "<div>No major festival or vratam is configured for this date.</div>";
}

async function load(){
  $("status").textContent="Calculating from astronomical ephemeris…";
  const date=$("date").value, place=$("place").value.trim();
  const url=new URL(`${API}/api/panchang`);
  url.searchParams.set("date",date); url.searchParams.set("place",place); url.searchParams.set("tradition",$("tradition").value);
  if(window.selectedCoords){url.searchParams.set("lat",window.selectedCoords.lat);url.searchParams.set("lng",window.selectedCoords.lng);url.searchParams.set("tz",Intl.DateTimeFormat().resolvedOptions().timeZone);}
  try{
    const r=await fetch(url); const data=await r.json();
    if(!r.ok) throw new Error(data.detail||"Panchang calculation failed");
    render(data); $("status").textContent="Live calculation complete.";
  }catch(e){console.error(e);$("status").textContent=`Error: ${e.message}`;}
}

$("date").value=isoToday();
$("load").onclick=load;
$("geo").onclick=()=>{
  if(!navigator.geolocation){$("status").textContent="Geolocation is not supported.";return;}
  $("status").textContent="Requesting your location…";
  navigator.geolocation.getCurrentPosition(p=>{
    window.selectedCoords={lat:p.coords.latitude,lng:p.coords.longitude};
    $("place").value=`My location (${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)})`;
    load();
  },e=>$("status").textContent=`Location error: ${e.message}`,{enableHighAccuracy:true,timeout:10000});
};
$("copy").onclick=async()=>{await navigator.clipboard.writeText($("sankalpam").textContent);$("status").textContent="Sankalpam copied.";};
load();
