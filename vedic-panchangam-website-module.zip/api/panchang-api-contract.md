# Panchang API contract

Your frontend expects:

GET /api/panchang?date=YYYY-MM-DD&place=...

Return JSON in this shape:

{
  "place": "Bengaluru, Karnataka, India",
  "timezone": "Asia/Kolkata",
  "lat": 12.9716,
  "lon": 77.5946,
  "date": "2026-09-06",
  "sunrise": "06:08 AM",
  "sunset": "06:28 PM",

  "vara": {"name":"Sunday","end":"Sunrise → next sunrise"},
  "tithi": {"name":"...","end":"until ..."},
  "nakshatra": {"name":"...","end":"until ..."},
  "yoga": {"name":"...","end":"until ..."},
  "karana": {"name":"...","end":"until ..."},

  "timings": {
    "rahu":"...",
    "yamaganda":"...",
    "gulika":"...",
    "durmuhurtham":"...",
    "varjyam":"...",
    "abhijit":"...",
    "amrita":"..."
  },

  "festivals": [
    {"name":"Festival name","type":"Festival / Vrata"}
  ],

  "calendar": {
    "samvatsara":"...",
    "ayana":"...",
    "ritu":"...",
    "masa":"...",
    "paksha":"..."
  },

  "locationPhrase":
    "Bengalūru-nagare, Karnāṭaka-rājye, Bhārata-deśe"
}

IMPORTANT:
- Use one consistent Panchangam calculation tradition across the site.
- Store latitude, longitude and timezone with every calculation.
- Do not copy a Panchangam time from one city to another.
- Keep festival calendars versioned by region/tradition.
- Keep the traditional Sanskrit geographic descriptor separate from raw GPS coordinates.
