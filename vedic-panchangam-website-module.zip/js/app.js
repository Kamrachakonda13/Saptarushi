const API_URL = "/api/panchang";

const demo = {
  place: "Bengaluru, Karnataka, India",
  timezone: "Asia/Kolkata",
  lat: 12.9716,
  lon: 77.5946,
  date: new Date().toISOString().slice(0,10),
  sunrise: "06:08 AM",
  sunset: "06:28 PM",
  vara: {name:"Sunday", end:"Sunrise → next sunrise"},
  tithi: {name:"Shukla Dashami", end:"until 08:42 PM"},
  nakshatra: {name:"Mrigashira", end:"until 09:18 PM"},
  yoga: {name:"Dhruva", end:"until 06:12 PM"},
  karana: {name:"Taitila", end:"until 08:42 PM"},
  timings: {
    rahu:"04:49 PM – 06:28 PM",
    yamaganda:"12:59 PM – 02:39 PM",
    gulika:"03:44 PM – 05:24 PM",
    durmuhurtham:"04:57 PM – 05:47 PM",
    varjyam:"02:18 AM – 03:46 AM",
    abhijit:"12:05 PM – 12:53 PM",
    amrita:"—"
  },
  festivals: [],
  locationPhrase: "Bengalūru-nagare, Karnāṭaka-rājye, Bhārata-deśe",
  calendar: {samvatsara:"Parabhava", ayana:"Dakshinayana", ritu:"Sharad", masa:"Bhadrapada", paksha:"Shukla"}
};

let current = {...demo};

const $ = id => document.getElementById(id);

function setText(id, value){ $(id).textContent = value ?? "—"; }

function formatDate(date){
  return new Intl.DateTimeFormat("en-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).format(date);
}

function render(data){
  current = data;
  const d = new Date((data.date || new Date().toISOString().slice(0,10))+"T12:00:00");
  setText("displayDate", formatDate(d));
  setText("locationText", `${data.place || "Selected location"} • ${data.timezone || ""}`);
  setText("sunrise", data.sunrise);
  setText("sunset", data.sunset);

  ["vara","tithi","nakshatra","yoga","karana"].forEach(k=>{
    setText(k, data[k]?.name);
    setText(k+"End", data[k]?.end);
  });

  Object.entries(data.timings || {}).forEach(([k,v])=>setText(k,v));

  const festivals = data.festivals || [];
  $("festivals").innerHTML = festivals.length
    ? festivals.map(f=>`<div class="festival">🪔 ${escapeHtml(f.name)}<small>${escapeHtml(f.type || "Festival / Vrata")}</small></div>`).join("")
    : `<div class="festival">No major festival recorded for this date in the selected calendar.</div>`;

  setText("locationPhrase", data.locationPhrase || "Configure a traditional regional descriptor.");
  renderSankalpam();
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}

function renderSankalpam(){
  const c = current.calendar || {};
  const tradition = $("tradition").value;
  const text =
`śrīmad-bhagavato mahāpuruṣasya viṣṇorājñayā pravartamānasya
adya brahmaṇaḥ dvitīye parārdhe śrī-śvetavarāha-kalpe
vaivasvata-manvantare kaliyuge prathame pāde
${c.samvatsara || "[saṃvatsara]"} nāma saṃvatsare
${c.ayana || "[ayana]"} ayane ${c.ritu || "[ṛtu]"} ṛtau
${c.masa || "[māsa]"} māse ${c.paksha || "[pakṣa]"} pakṣe
${current.tithi?.name || "[tithi]"} tithau
${current.vara?.name || "[vāra]"} vāsare
${current.nakshatra?.name || "[nakṣatra]"} nakṣatre
${current.locationPhrase || "[deśa/pradeśa]"}
mama upātta-samasta-durita-kṣaya-dvāra
śrī-parameśvara-prītyarthaṃ
[desired saṅkalpa / pūjā / japa / vrata] kariṣye.`;

  $("sankalpam").textContent = text;
}

async function loadPanchang(){
  const date = $("date").value;
  const place = $("place").value.trim();

  try{
    // Expected backend contract:
    // GET /api/panchang?date=YYYY-MM-DD&place=... 
    // or replace with your own endpoint.
    const url = `${API_URL}?date=${encodeURIComponent(date)}&place=${encodeURIComponent(place)}`;
    const res = await fetch(url);
    if(!res.ok) throw new Error("API unavailable");
    render(await res.json());
  }catch(e){
    // Demo fallback keeps the UI usable before your calculation API is connected.
    render({...demo, date, place});
  }
}

$("date").value = new Date().toISOString().slice(0,10);
$("refreshBtn").addEventListener("click", loadPanchang);
$("tradition").addEventListener("change", renderSankalpam);

$("copySankalpam").addEventListener("click", async ()=>{
  await navigator.clipboard.writeText($("sankalpam").textContent);
  $("copySankalpam").textContent = "Copied ✓";
  setTimeout(()=> $("copySankalpam").textContent="Copy Sankalpam",1500);
});

$("locateBtn").addEventListener("click", ()=>{
  if(!navigator.geolocation){
    alert("Geolocation is not supported by this browser.");
    return;
  }
  navigator.geolocation.getCurrentPosition(pos=>{
    const {latitude,longitude} = pos.coords;
    $("place").value = `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
    loadPanchang();
  }, ()=>alert("Location permission was not granted."));
});

render(demo);
