# Vedic Panchangam Website Module

This package adds a location-aware daily Panchangam panel to the Sacred India temple website.

## Included

- Tithi
- Vara / weekday
- Nakshatra
- Yoga
- Karana
- Sunrise / sunset
- Rahu Kalam
- Yamaganda
- Gulika
- Durmuhurtham
- Varjyam
- Abhijit Muhurta
- Amrita Kalam
- Festival / Vrata highlighting
- Location-aware Sankalpam
- Copy Sankalpam button
- Responsive UI
- Geolocation button
- API contract for plugging in a real Panchang calculation engine

## Files

index.html
css/styles.css
js/app.js
data/festivals.json
api/panchang-api-contract.md

## Production integration

The browser calls:

GET /api/panchang?date=YYYY-MM-DD&place=...

Replace the demo fallback with your server-side Panchang calculation.

For a robust production system, calculate astronomy with a trusted ephemeris such as Swiss Ephemeris and apply your selected ayanamsa / Panchangam tradition consistently.

Do not mix timings from multiple Panchangam providers.

## Sankalpam

The module deliberately treats the traditional geographic phrase as a separate field. For example, a temple profile can provide a phrase such as:

"śrīśailasya āgneya-pradeśe"

while a user's home location can have its own configured traditional phrase.

This is safer than attempting to manufacture a traditional Sanskrit place-description solely from latitude/longitude.

## Festivals

Keep festival records in data/festivals.json or, preferably, a database keyed by:

date + region + calendar tradition.

A festival can have:

name
type
regionalName
color
priority
source
notes

## Disclaimer

Panchangam traditions can differ in ayanamsa, sunrise convention, lunar-month convention and regional festival rules. For important religious rites, users should verify the local temple or family tradition.
